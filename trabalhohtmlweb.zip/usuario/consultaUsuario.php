<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">

    <title>Cadastro de usuário</title>
  </head>
  <body>
      <div class="container">
            <h1>Tela de consulta</h1>
            <hr>
            <a href="../menu.php"> < Voltar</a>
            <br><br> 
            
            <a class="btn btn-primary" href="incluirUsuario.php" role="button">Incluir</a>
            <br><br>
            
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Login</th>
                        <th>Senha</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
            
                    <?php
                    
                        include_once("../servico/Bd.php");
                        
                        $bd = new Bd();
                        
                        $sql = "select * from usuario_3003";
                        
                        foreach ($bd->query($sql) as $row) {
                            echo "<tr>";
                            echo "<td>".$row['id'] . "</td>";
                            echo "<td>".$row['login'] . "</td>";
                            echo "<td>".$row['senha'] . "</td>";
                            echo "<td><a href='#' onclick=Pergunta(".$row['id'].")>Excluir</a></td>";
                            echo "<td><a href='alterarUsuario.php?id=".$row['id'] . "'>Alterar</a></td>";
                            echo "</tr>";
                        }
                    
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Login</th>
                        <th>Senha</th>
                        <th></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
            
            <script>
            
            function Pergunta(id){
                if (confirm("Deseja excluir ?")) {
                 window.location.replace("https://gyrate-store.000webhostapp.com/usuario/excluirUsuario.php?id="+id);
                }
            }
                
            </script>
     
  </body>
</html>